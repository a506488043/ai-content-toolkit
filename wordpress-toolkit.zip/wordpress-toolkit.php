<?php
/**
 * Plugin Name: WordPress Toolkit
 * Plugin URI: https://www.saiita.com.cn
 * Description: 一个集成了网站卡片、年龄计算器、物品管理、友情链接、自动摘要生成、Cookie同意通知和REST代理修复的综合工具包。
 * Version: 1.0.5
 * Author: www.saiita.com.cn
 * Author URI: https://www.saiita.com.cn
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wordpress-toolkit
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Network: false
 */

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 定义插件常量
define('WORDPRESS_TOOLKIT_VERSION', '1.0.5');
define('WORDPRESS_TOOLKIT_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WORDPRESS_TOOLKIT_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('WORDPRESS_TOOLKIT_PLUGIN_BASENAME', plugin_basename(__FILE__));

// 国际化支持已移除 - 直接使用WordPress原生翻译函数

// 加载日志管理
require_once WORDPRESS_TOOLKIT_PLUGIN_PATH . 'includes/class-logger.php';

// 加载管理页面模板系统
require_once WORDPRESS_TOOLKIT_PLUGIN_PATH . 'includes/class-admin-page-template.php';

// 加载REST代理修复模块
require_once WORDPRESS_TOOLKIT_PLUGIN_PATH . 'modules/rest-proxy-fix.php';

/**
 * WordPress Toolkit 主类
 */
class WordPress_Toolkit {
    
    /**
     * 单例实例
     */
    private static $instance = null;
    
    /**
     * 子模块实例
     */
    private $custom_card = null;
    private $age_calculator = null;
    private $time_capsule = null;
    private $cookieguard = null;
    private $simple_friendlink = null;
    private $simple_friendlink_admin = null;
    private $auto_excerpt = null;
    
    /**
     * 获取单例实例
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 构造函数
     */
    private function __construct() {
        $this->init_hooks();
        $this->load_modules();
    }
    
    /**
     * 初始化钩子
     */
    private function init_hooks() {
        // 插件激活和停用钩子
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // WordPress初始化钩子
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // 插件链接
        add_filter('plugin_action_links_' . WORDPRESS_TOOLKIT_PLUGIN_BASENAME, array($this, 'add_plugin_links'));
    }
    
    /**
     * 加载子模块
     */
    private function load_modules() {
        // 加载Custom Card模块
        require_once WORDPRESS_TOOLKIT_PLUGIN_PATH . 'modules/custom-card/custom-card-module.php';
        $this->custom_card = new Custom_Card_Module();
        
        // 加载Age Calculator模块
        require_once WORDPRESS_TOOLKIT_PLUGIN_PATH . 'modules/age-calculator/age-calculator-module.php';
        $this->age_calculator = new Age_Calculator_Module();
        
        // 加载Time Capsule模块
        require_once WORDPRESS_TOOLKIT_PLUGIN_PATH . 'modules/time-capsule/time-capsule-module.php';
        $this->time_capsule = new Time_Capsule_Module();
        
        // 加载CookieGuard模块
        require_once WORDPRESS_TOOLKIT_PLUGIN_PATH . 'modules/cookieguard/cookieguard-module.php';
        $this->cookieguard = CookieGuard_Module::get_instance();

        // 加载Simple FriendLink模块
        require_once WORDPRESS_TOOLKIT_PLUGIN_PATH . 'modules/simple-friendlink/simple-friendlink-module.php';
        $this->simple_friendlink = Simple_FriendLink_Module::get_instance();

        // 加载Simple FriendLink管理页面
        require_once WORDPRESS_TOOLKIT_PLUGIN_PATH . 'modules/simple-friendlink/admin.php';
        $this->simple_friendlink_admin = new Simple_FriendLink_Admin();

        // 加载Auto Excerpt模块
        require_once WORDPRESS_TOOLKIT_PLUGIN_PATH . 'modules/auto-excerpt/auto-excerpt-module.php';
        $this->auto_excerpt = Auto_Excerpt_Module::get_instance();

        // Auto Excerpt 管理功能已整合到设置页面，无需额外加载

        // 调试日志
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('WordPress Toolkit: Modules loaded - Custom Card: ' . ($this->custom_card ? 'Yes' : 'No'));
        }
    }
    
    /**
     * 插件激活
     */
    public function activate() {
        // 先加载模块
        $this->load_modules();
        
        // 激活所有子模块
        if ($this->custom_card) $this->custom_card->activate();
        if ($this->age_calculator) $this->age_calculator->activate();
        if ($this->time_capsule) $this->time_capsule->activate();
        if ($this->cookieguard) $this->cookieguard->activate();
        if ($this->simple_friendlink) $this->simple_friendlink->activate();
        if ($this->auto_excerpt) $this->auto_excerpt->activate();
        
        // 设置插件激活时间
        add_option('wordpress_toolkit_activated_time', current_time('timestamp'));
    }
    
    /**
     * 插件停用
     */
    public function deactivate() {
        // 停用所有子模块
        if ($this->custom_card) $this->custom_card->deactivate();
        if ($this->age_calculator) $this->age_calculator->deactivate();
        if ($this->time_capsule) $this->time_capsule->deactivate();
        if ($this->cookieguard) $this->cookieguard->deactivate();
        if ($this->simple_friendlink) $this->simple_friendlink->deactivate();
        if ($this->auto_excerpt) $this->auto_excerpt->deactivate();
    }
    
    /**
     * 初始化
     */
    public function init() {
        // 加载文本域
        load_plugin_textdomain('wordpress-toolkit', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // 初始化所有子模块
        if ($this->custom_card) $this->custom_card->init();
        if ($this->age_calculator) $this->age_calculator->init();
        if ($this->time_capsule) $this->time_capsule->init();
        if ($this->cookieguard) $this->cookieguard->init();
        if ($this->simple_friendlink) $this->simple_friendlink->init();
        if ($this->auto_excerpt) $this->auto_excerpt->init();
    }
    
    /**
     * 添加管理菜单 - 重新组织结构
     */
    public function add_admin_menu() {
        // ======================
        // 工具箱菜单 - 数据查看和操作
        // ======================

        // 添加主菜单 - 使用较低权限让订阅者也能看到
        add_menu_page(
            'WordPress Toolkit',
            __('工具箱', 'wordpress-toolkit'),
            'read', // 使用基础阅读权限，所有登录用户都有
            'wordpress-toolkit',
            array($this, 'admin_page'),
            'dashicons-admin-tools',
            30
        );

        // 网站卡片（仅管理员可见）
        if (current_user_can('manage_options')) {
            add_submenu_page(
                'wordpress-toolkit',
                __('网站卡片', 'wordpress-toolkit'),
                __('网站卡片', 'wordpress-toolkit'),
                'manage_options',
                'wordpress-toolkit-cards-list',
                array($this, 'custom_cards_list_page')
            );
        }

        // 物品管理（订阅者和管理员都可见）
        add_submenu_page(
            'wordpress-toolkit',
            __('物品管理', 'wordpress-toolkit'),
            __('物品管理', 'wordpress-toolkit'),
            'read', // 使用基础阅读权限
            'wordpress-toolkit-time-capsule',
            array($this, 'time_capsule_admin_page')
        );

        // 友情链接（仅管理员可见）
        if (current_user_can('manage_options')) {
            add_submenu_page(
                'wordpress-toolkit',
                __('友情链接', 'wordpress-toolkit'),
                __('友情链接', 'wordpress-toolkit'),
                'manage_options',
                'wordpress-toolkit-friendlinks',
                array($this, 'friendlinks_admin_page')
            );
        }

        // 自动摘要（仅管理员可见）
        if (current_user_can('manage_options')) {
            add_submenu_page(
                'wordpress-toolkit',
                __('自动摘要', 'wordpress-toolkit'),
                __('自动摘要', 'wordpress-toolkit'),
                'manage_options',
                'wordpress-toolkit-auto-excerpt',
                array($this, 'auto_excerpt_admin_page')
            );
        }


        // ======================
        // 设置菜单 - 插件配置
        // ======================

        // 网站卡片设置
        add_options_page(
            __('网站卡片设置', 'wordpress-toolkit'),
            __('网站卡片', 'wordpress-toolkit'),
            'manage_options',
            'wordpress-toolkit-custom-card-settings',
            array($this, 'custom_card_settings_page')
        );

        // 年龄计算器设置
        add_options_page(
            __('年龄计算器设置', 'wordpress-toolkit'),
            __('年龄计算器', 'wordpress-toolkit'),
            'manage_options',
            'wordpress-toolkit-age-calculator-settings',
            array($this, 'age_calculator_settings_page')
        );

        // Cookie同意设置
        add_options_page(
            __('Cookie同意设置', 'wordpress-toolkit'),
            __('Cookie同意', 'wordpress-toolkit'),
            'manage_options',
            'wordpress-toolkit-cookieguard-settings',
            array($this, 'cookieguard_settings_page')
        );

        // 简洁友情链接设置
        add_options_page(
            __('简洁友情链接', 'wordpress-toolkit'),
            __('简洁友情链接', 'wordpress-toolkit'),
            'manage_options',
            'wordpress-toolkit-simple-friendlink-settings',
            array($this, 'simple_friendlink_settings_page')
        );

        // 自动摘要设置
        add_options_page(
            __('自动摘要设置', 'wordpress-toolkit'),
            __('自动摘要', 'wordpress-toolkit'),
            'manage_options',
            'wordpress-toolkit-auto-excerpt-settings',
            array($this, 'auto_excerpt_settings_page')
        );
    }
    
    /**
     * 加载管理后台脚本和样式
     */
    public function admin_enqueue_scripts($hook) {
        // 只在插件相关页面加载统一样式和脚本
        if (strpos($hook, 'wordpress-toolkit') !== false || strpos($hook, 'options-general') !== false) {
            // 加载统一CSS变量
            wp_enqueue_style(
                'toolkit-variables',
                WORDPRESS_TOOLKIT_PLUGIN_URL . 'assets/css/variables.css',
                array(),
                WORDPRESS_TOOLKIT_VERSION
            );

            // 加载通用样式
            wp_enqueue_style(
                'toolkit-common',
                WORDPRESS_TOOLKIT_PLUGIN_URL . 'assets/css/common.css',
                array('toolkit-variables'),
                WORDPRESS_TOOLKIT_VERSION
            );

            // 加载核心JavaScript框架
            wp_enqueue_script(
                'toolkit-core',
                WORDPRESS_TOOLKIT_PLUGIN_URL . 'assets/js/toolkit-core.js',
                array('jquery'),
                WORDPRESS_TOOLKIT_VERSION,
                true
            );

            // 加载迁移助手
            wp_enqueue_script(
                'toolkit-migration',
                WORDPRESS_TOOLKIT_PLUGIN_URL . 'assets/js/migration-helper.js',
                array('jquery', 'toolkit-core'),
                WORDPRESS_TOOLKIT_VERSION,
                true
            );

            // 传递配置到JavaScript
            wp_localize_script('toolkit-core', 'ToolkitConfig', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('toolkit_nonce'),
                'strings' => array(
                    'saveSuccess' => __('保存成功！', 'wordpress-toolkit'),
                    'saveError' => __('保存失败，请重试。', 'wordpress-toolkit'),
                    'networkError' => __('网络错误，请重试。', 'wordpress-toolkit'),
                    'confirmDelete' => __('确定要删除这个项目吗？此操作不可撤销。', 'wordpress-toolkit'),
                    'deleteSuccess' => __('删除成功！', 'wordpress-toolkit'),
                    'deleteError' => __('删除失败，请重试。', 'wordpress-toolkit'),
                    'loading' => __('加载中...', 'wordpress-toolkit'),
                    'processing' => __('处理中...', 'wordpress-toolkit'),
                    'confirm' => __('确定', 'wordpress-toolkit'),
                    'cancel' => __('取消', 'wordpress-toolkit')
                )
            ));
        }

        // 加载子模块的资源（已重构，主要加载模块特定资源）
        if ($this->custom_card) $this->custom_card->admin_enqueue_scripts($hook);
        if ($this->age_calculator) $this->age_calculator->admin_enqueue_scripts($hook);
        if ($this->time_capsule) $this->time_capsule->admin_enqueue_scripts($hook);
        if ($this->cookieguard) $this->cookieguard->admin_enqueue_scripts($hook);
        if ($this->auto_excerpt) $this->auto_excerpt->admin_enqueue_scripts($hook);
        // Simple_FriendLink_Module 不需要特殊的管理页面资源加载
    }
    
    /**
     * 加载前端脚本和样式
     */
    public function enqueue_scripts() {
        // 加载子模块的前端资源
        if ($this->custom_card) $this->custom_card->enqueue_scripts();
        if ($this->age_calculator) $this->age_calculator->enqueue_scripts();
        if ($this->time_capsule) $this->time_capsule->enqueue_scripts();
        if ($this->cookieguard) $this->cookieguard->enqueue_scripts();
        if ($this->simple_friendlink) $this->simple_friendlink->enqueue_scripts();
        if ($this->auto_excerpt) $this->auto_excerpt->enqueue_scripts();
    }
    
    /**
     * 主管理页面 - 安全版本（简化版）
     */
    public function admin_page() {
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            wp_die(__('权限不足', 'wordpress-toolkit'));
        }

        // 显示工具箱主页面，包含功能说明
        $this->toolbox_about_page();
    }
    
    /**
     * 网站卡片设置页面 - 放在设置菜单中
     */
    public function custom_card_settings_page() {
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            wp_die(__('权限不足', 'wordpress-toolkit'));
        }

        // 验证nonce（防止CSRF攻击）
        if (isset($_POST['action']) && !wp_verify_nonce($_POST['_wpnonce'], 'wordpress_toolkit_custom_card')) {
            wp_die(__('安全验证失败', 'wordpress-toolkit'));
        }

        // 调试日志
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('WordPress Toolkit: Custom Card settings page called');
        }

        if ($this->custom_card) {
            // 调用自定义卡片模块的设置页面（只显示设置选项卡）
            $this->custom_card->settings_page();
        } else {
            echo '<div class="wrap"><h1>网站卡片设置</h1><div class="error"><p>Custom Card 模块未正确加载，请检查插件设置。</p></div></div>';
        }
    }

    /**
     * 年龄计算器设置页面 - 放在设置菜单中
     */
    public function age_calculator_settings_page() {
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            wp_die(__('权限不足', 'wordpress-toolkit'));
        }

        // 验证nonce（防止CSRF攻击）
        if (isset($_POST['action']) && !wp_verify_nonce($_POST['_wpnonce'], 'wordpress_toolkit_age_calculator')) {
            wp_die(__('安全验证失败', 'wordpress-toolkit'));
        }

        if ($this->age_calculator) {
            // 调用年龄计算器模块的设置页面
            $this->age_calculator->settings_page();
        } else {
            echo '<div class="wrap"><h1>年龄计算器设置</h1><div class="error"><p>Age Calculator 模块未正确加载，请检查插件设置。</p></div></div>';
        }
    }

    /**
     * 物品管理设置页面 - 放在设置菜单中
     */
    public function time_capsule_settings_page() {
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            wp_die(__('权限不足', 'wordpress-toolkit'));
        }

        // 验证nonce（防止CSRF攻击）
        if (isset($_POST['action']) && !wp_verify_nonce($_POST['_wpnonce'], 'wordpress_toolkit_time_capsule')) {
            wp_die(__('安全验证失败', 'wordpress-toolkit'));
        }

        if ($this->time_capsule) {
            // 调用时间胶囊模块的设置页面
            $this->time_capsule->settings_page();
        } else {
            echo '<div class="wrap"><h1>物品管理设置</h1><div class="error"><p>Time Capsule 模块未正确加载，请检查插件设置。</p></div></div>';
        }
    }

    /**
     * Cookie同意设置页面 - 放在设置菜单中
     */
    public function cookieguard_settings_page() {
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            wp_die(__('权限不足', 'wordpress-toolkit'));
        }

        // 验证nonce（防止CSRF攻击）
        if (isset($_POST['action']) && !wp_verify_nonce($_POST['_wpnonce'], 'wordpress_toolkit_cookieguard')) {
            wp_die(__('安全验证失败', 'wordpress-toolkit'));
        }

        // 处理表单提交
        if (isset($_POST['action']) && $_POST['action'] === 'save_cookieguard_settings') {
            $this->save_cookieguard_settings();
        }

        // 获取设置
        $settings = get_option('wordpress_toolkit_cookieguard_settings', array(
            'cookie_types' => array(),
            'theme' => 'light',
            'position' => 'bottom',
            'learn_more_url' => '',
            'privacy_policy_url' => '',
            'consent_expiry_days' => 365
        ));

        // 添加设置页面样式
        wp_enqueue_style('cookieguard-admin', plugins_url('assets/cookieguard-admin.css', __FILE__));
        ?>
        <div class="wrap">
            <h1><?php _e('Cookie同意设置', 'wordpress-toolkit'); ?></h1>

            <form method="post" action="">
                <input type="hidden" name="action" value="save_cookieguard_settings">
                <?php wp_nonce_field('wordpress_toolkit_cookieguard'); ?>

                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Cookie类型', 'wordpress-toolkit'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="cookie_types[]" value="necessary" checked disabled>
                                <?php _e('必要Cookie', 'wordpress-toolkit'); ?> (<?php _e('始终启用', 'wordpress-toolkit'); ?>)
                            </label><br>
                            <label>
                                <input type="checkbox" name="cookie_types[]" value="functional" <?php echo in_array('functional', $settings['cookie_types']) ? 'checked' : ''; ?>>
                                <?php _e('功能性Cookie', 'wordpress-toolkit'); ?>
                            </label><br>
                            <label>
                                <input type="checkbox" name="cookie_types[]" value="analytics" <?php echo in_array('analytics', $settings['cookie_types']) ? 'checked' : ''; ?>>
                                <?php _e('分析性Cookie', 'wordpress-toolkit'); ?>
                            </label><br>
                            <label>
                                <input type="checkbox" name="cookie_types[]" value="marketing" <?php echo in_array('marketing', $settings['cookie_types']) ? 'checked' : ''; ?>>
                                <?php _e('营销性Cookie', 'wordpress-toolkit'); ?>
                            </label>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><?php _e('主题', 'wordpress-toolkit'); ?></th>
                        <td>
                            <select name="theme">
                                <option value="light" <?php selected($settings['theme'], 'light'); ?>><?php _e('浅色', 'wordpress-toolkit'); ?></option>
                                <option value="dark" <?php selected($settings['theme'], 'dark'); ?>><?php _e('深色', 'wordpress-toolkit'); ?></option>
                                <option value="auto" <?php selected($settings['theme'], 'auto'); ?>><?php _e('自动', 'wordpress-toolkit'); ?></option>
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><?php _e('位置', 'wordpress-toolkit'); ?></th>
                        <td>
                            <select name="position">
                                <option value="bottom" <?php selected($settings['position'], 'bottom'); ?>><?php _e('底部', 'wordpress-toolkit'); ?></option>
                                <option value="top" <?php selected($settings['position'], 'top'); ?>><?php _e('顶部', 'wordpress-toolkit'); ?></option>
                                <option value="center" <?php selected($settings['position'], 'center'); ?>><?php _e('居中', 'wordpress-toolkit'); ?></option>
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><?php _e('了解更多链接', 'wordpress-toolkit'); ?></th>
                        <td>
                            <input type="url" name="learn_more_url" value="<?php echo esc_url($settings['learn_more_url']); ?>" class="regular-text">
                            <p class="description"><?php _e('Cookie使用说明页面链接', 'wordpress-toolkit'); ?></p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><?php _e('隐私政策链接', 'wordpress-toolkit'); ?></th>
                        <td>
                            <input type="url" name="privacy_policy_url" value="<?php echo esc_url($settings['privacy_policy_url']); ?>" class="regular-text">
                            <p class="description"><?php _e('隐私政策页面链接', 'wordpress-toolkit'); ?></p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><?php _e('同意有效期', 'wordpress-toolkit'); ?></th>
                        <td>
                            <input type="number" name="consent_expiry_days" value="<?php echo $settings['consent_expiry_days']; ?>" min="1" max="3650" step="1">
                            <p class="description"><?php _e('用户Cookie同意记录的有效天数（默认：365天）', 'wordpress-toolkit'); ?></p>
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <input type="submit" name="save_settings" class="button button-primary" value="<?php _e('保存设置', 'wordpress-toolkit'); ?>">
                </p>
            </form>
        </div>
        <?php
    }

    /**
     * 保存CookieGuard设置
     */
    private function save_cookieguard_settings() {
        if (!current_user_can('manage_options')) {
            wp_die(__('权限不足', 'wordpress-toolkit'));
        }

        $cookie_types = isset($_POST['cookie_types']) ? array_map('sanitize_text_field', $_POST['cookie_types']) : array();

        $settings = array(
            'cookie_types' => $cookie_types,
            'theme' => sanitize_text_field($_POST['theme']),
            'position' => sanitize_text_field($_POST['position']),
            'learn_more_url' => esc_url_raw($_POST['learn_more_url']),
            'privacy_policy_url' => esc_url_raw($_POST['privacy_policy_url']),
            'consent_expiry_days' => intval($_POST['consent_expiry_days'])
        );

        update_option('wordpress_toolkit_cookieguard_settings', $settings);

        // 显示成功消息
        add_settings_error('wordpress_toolkit_cookieguard_settings', 'settings_saved', __('设置已保存', 'wordpress-toolkit'), 'updated');
        set_transient('settings_errors', get_settings_errors(), 30);
    }

    /**
     * 简洁友情链接设置页面
     */
    public function simple_friendlink_settings_page() {
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            wp_die(__('权限不足', 'wordpress-toolkit'));
        }

        // 保存设置
        if (isset($_POST['save_settings'])) {
            $settings = array(
                'allow_user_submit' => isset($_POST['allow_user_submit']),
                'require_login' => isset($_POST['require_login']),
                'admin_approval' => isset($_POST['admin_approval']),
                'max_links_per_page' => intval($_POST['max_links_per_page'])
            );

            if (class_exists('Simple_FriendLink_Module')) {
                $friendlink_module = Simple_FriendLink_Module::get_instance();
                $friendlink_module->save_settings($settings);
                echo '<div class="notice notice-success is-dismissible"><p>' . __('设置保存成功！', 'wordpress-toolkit') . '</p></div>';
            }
        }

        // 获取当前设置
        if (class_exists('Simple_FriendLink_Module')) {
            $friendlink_module = Simple_FriendLink_Module::get_instance();
            $settings = $friendlink_module->get_settings();
        } else {
            $settings = array(
                'allow_user_submit' => true,
                'require_login' => true,
                'admin_approval' => false,
                'max_links_per_page' => 30
            );
        }

        // 显示设置表单
        ?>
        <div class="wrap">
            <h1><?php echo __('简洁友情链接设置', 'wordpress-toolkit'); ?></h1>

            <form method="post" action="">
                <?php wp_nonce_field('wordpress_toolkit_simple_friendlink'); ?>

                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('用户提交', 'wordpress-toolkit'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="allow_user_submit" value="1" <?php checked($settings['allow_user_submit']); ?>>
                                <?php _e('允许用户提交友情链接', 'wordpress-toolkit'); ?>
                            </label>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><?php _e('需要登录', 'wordpress-toolkit'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="require_login" value="1" <?php checked($settings['require_login']); ?>>
                                <?php _e('用户必须登录才能提交', 'wordpress-toolkit'); ?>
                            </label>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><?php _e('管理员审核', 'wordpress-toolkit'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="admin_approval" value="1" <?php checked($settings['admin_approval']); ?>>
                                <?php _e('用户提交的链接需要管理员审核', 'wordpress-toolkit'); ?>
                            </label>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><?php _e('每页显示数量', 'wordpress-toolkit'); ?></th>
                        <td>
                            <input type="number" name="max_links_per_page" value="<?php echo $settings['max_links_per_page']; ?>" min="5" max="50" step="5">
                            <p class="description"><?php _e('友情链接页面每页显示的链接数量（默认：30）', 'wordpress-toolkit'); ?></p>
                        </td>
                    </tr>

                                    </table>

                <p class="submit">
                    <input type="submit" name="save_settings" class="button button-primary" value="<?php _e('保存设置', 'wordpress-toolkit'); ?>">
                </p>
            </form>
        </div>
        <?php
    }

    /**
     * 自动摘要管理页面 - 工具箱菜单中
     */
    public function auto_excerpt_admin_page() {
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            wp_die(__('权限不足', 'wordpress-toolkit'));
        }

        // 验证nonce（防止CSRF攻击）
        if (isset($_POST['action']) && !wp_verify_nonce($_POST['_wpnonce'], 'wordpress_toolkit_auto_excerpt')) {
            wp_die(__('安全验证失败', 'wordpress-toolkit'));
        }

        // 显示管理页面
        if ($this->auto_excerpt) {
            ?>
            <div class="wrap">
                <?php
                error_log("WordPress Toolkit: Loading auto excerpt admin page");
                $stats = $this->auto_excerpt->get_excerpt_stats();
                error_log("WordPress Toolkit: Stats loaded - " . print_r($stats, true));
                ?>

                <div class="postbox" style="margin-top: 15px; margin-bottom: 10px;">
                    <div class="inside" style="padding: 12px 15px;">
                        <div style="display: flex; align-items: center; gap: 30px; padding: 0; flex-wrap: wrap; justify-content: space-between;">
                            <div>
                                <strong><?php _e('文章总数', 'wordpress-toolkit'); ?></strong>
                                <div style="margin-top: 5px;">
                                    <span class="dashicons dashicons-post" style="color: #0073aa;"></span>
                                    <?php echo number_format($stats['total_posts']); ?>
                                </div>
                            </div>
                            <div>
                                <strong><?php _e('有摘要文章', 'wordpress-toolkit'); ?></strong>
                                <div style="margin-top: 5px;">
                                    <span class="dashicons dashicons-yes-alt" style="color: #00a32a;"></span>
                                    <?php echo number_format($stats['with_excerpt']); ?>
                                </div>
                            </div>
                            <div>
                                <strong><?php _e('无摘要文章数量', 'wordpress-toolkit'); ?></strong>
                                <div style="margin-top: 5px;">
                                    <span class="dashicons dashicons-no-alt" style="color: #d63638;"></span>
                                    <?php echo number_format($stats['without_excerpt']); ?>
                                </div>
                            </div>
                            <div>
                                <strong><?php _e('摘要覆盖率', 'wordpress-toolkit'); ?></strong>
                                <div style="margin-top: 5px; display: flex; align-items: center; gap: 10px;">
                                    <span class="dashicons dashicons-chart-bar" style="color: #0073aa;"></span>
                                    <span><?php echo $stats['coverage_rate']; ?>%</span>
                                    <?php if ($stats['ai_generated'] > 0): ?>
                                        <span class="badge-ai" style="background: #f0f6fc; color: #0073aa; padding: 2px 6px; border-radius: 3px; font-size: 12px; border: 1px solid #c3d9ea;">🤖 <?php echo sprintf(__('AI生成：%d篇', 'wordpress-toolkit'), $stats['ai_generated']); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="postbox" style="margin-top: 10px;">
                    <div class="inside" style="padding: 15px;">
                        <?php
                        // 获取分页数据（在这里提前获取，以便在筛选器行显示分页）
                        $current_page = isset($_GET['paged']) ? intval($_GET['paged']) : 1;
                        $status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'all';

                        error_log("WordPress Toolkit: Loading excerpt list - page: $current_page, status: $status");
                        $excerpt_list = $this->auto_excerpt->get_excerpt_list($current_page, 15, $status);
                        error_log("WordPress Toolkit: Excerpt list loaded - " . print_r($excerpt_list, true));
                        ?>

                        <!-- 筛选器、批量操作和分页放在同一行 -->
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; flex-wrap: wrap; gap: 15px;">
                            <!-- 左侧：筛选器和批量操作 -->
                            <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                                <form method="get" action="" style="display: flex; align-items: center; gap: 10px; margin: 0;">
                                    <input type="hidden" name="page" value="wordpress-toolkit-auto-excerpt">
                                    <select name="status" id="excerpt-status-filter">
                                        <option value="all" <?php selected(isset($_GET['status']) ? $_GET['status'] : 'all', 'all'); ?>><?php _e('全部文章', 'wordpress-toolkit'); ?></option>
                                        <option value="with_excerpt" <?php selected(isset($_GET['status']) ? $_GET['status'] : 'all', 'with_excerpt'); ?>><?php _e('有摘要文章', 'wordpress-toolkit'); ?></option>
                                        <option value="without_excerpt" <?php selected(isset($_GET['status']) ? $_GET['status'] : 'all', 'without_excerpt'); ?>><?php _e('无摘要文章', 'wordpress-toolkit'); ?></option>
                                    </select>
                                    <button type="submit" class="button"><?php _e('筛选', 'wordpress-toolkit'); ?></button>

                                    <span style="margin: 0 5px; color: #666;">|</span>

                                    <button type="button" id="batch-generate-excerpts" class="button button-primary">
                                        <?php _e('为无摘要文章生成摘要', 'wordpress-toolkit'); ?>
                                    </button>
                                    <span class="spinner" id="batch-generate-spinner" style="display: none; margin-left: 5px;"></span>
                                </form>
                            </div>

                            <!-- 右侧：分页 -->
                            <?php if (!empty($excerpt_list) && isset($excerpt_list['pages']) && $excerpt_list['pages'] > 1): ?>
                            <div class="tablenav-pages" style="margin: 0;">
                                <?php
                                $current_url = admin_url('admin.php?page=wordpress-toolkit-auto-excerpt');
                                if (isset($_GET['status'])) {
                                    $current_url .= '&status=' . urlencode($_GET['status']);
                                }
                                ?>
                                <span class="displaying-num">
                                    <?php printf(__('共 %d 个项目', 'wordpress-toolkit'), $excerpt_list['total']); ?>
                                </span>
                                <?php
                                // 使用WordPress标准的paginate_links函数，与网站卡片保持一致
                                echo paginate_links(array(
                                    'base' => $current_url . '&paged=%#%',
                                    'format' => '',
                                    'prev_text' => __('&laquo; 上一页'),
                                    'next_text' => __('下一页 &raquo;'),
                                    'total' => $excerpt_list['pages'],
                                    'current' => $current_page
                                ));
                                ?>
                            </div>
                            <?php endif; ?>
                        </div>

                        <!-- 批量操作结果 -->
                        <div id="batch-generate-result" style="display: none; margin: 15px 0;"></div>

                        <!-- 文章列表 -->
                        <?php
                        // 添加调试信息和错误处理
                        if (empty($excerpt_list) || !isset($excerpt_list['posts'])) {
                            echo '<div class="notice notice-warning"><p>摘要列表数据加载失败，请检查错误日志。</p></div>';
                            error_log("WordPress Toolkit: Excerpt list data is invalid");
                        } elseif (empty($excerpt_list['posts'])) {
                            // 显示空状态，参考网站卡片样式
                            ?>
                            <table class="wp-list-table widefat fixed striped">
                                <thead>
                                    <tr>
                                        <th scope="col" width="35%"><?php _e('标题', 'wordpress-toolkit'); ?></th>
                                        <th scope="col" width="10%"><?php _e('摘要状态', 'wordpress-toolkit'); ?></th>
                                        <th scope="col" width="10%"><?php _e('摘要长度', 'wordpress-toolkit'); ?></th>
                                        <th scope="col" width="10%"><?php _e('内容长度', 'wordpress-toolkit'); ?></th>
                                        <th scope="col" width="15%"><?php _e('发布日期', 'wordpress-toolkit'); ?></th>
                                        <th scope="col" width="20%"><?php _e('操作', 'wordpress-toolkit'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td colspan="6" style="text-align: center; padding: 40px;">
                                            <?php
                                            $current_status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'all';
                                            if ($current_status !== 'all'):
                                            ?>
                                            <div style="font-size: 16px; color: #666; margin-bottom: 20px;">
                                                <span class="dashicons dashicons-search" style="font-size: 48px; color: #ccc; display: block; margin-bottom: 10px;"></span>
                                                没有找到匹配的<?php echo $current_status === 'with_excerpt' ? '有摘要' : '无摘要'; ?>文章
                                            </div>
                                            <a href="<?php echo admin_url('admin.php?page=wordpress-toolkit-auto-excerpt'); ?>" class="button button-primary">
                                                清除筛选条件
                                            </a>
                                            <?php else: ?>
                                            <div style="font-size: 16px; color: #666; margin-bottom: 20px;">
                                                <span class="dashicons dashicons-edit-page" style="font-size: 48px; color: #ccc; display: block; margin-bottom: 10px;"></span>
                                                暂无文章数据
                                            </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <?php
                            error_log("WordPress Toolkit: No posts found matching criteria");
                        } else {
                            error_log("WordPress Toolkit: Displaying " . count($excerpt_list['posts']) . " posts");
                        ?>
            
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th scope="col" width="35%"><?php _e('标题', 'wordpress-toolkit'); ?></th>
                                    <th scope="col" width="10%"><?php _e('摘要状态', 'wordpress-toolkit'); ?></th>
                                    <th scope="col" width="10%"><?php _e('摘要长度', 'wordpress-toolkit'); ?></th>
                                    <th scope="col" width="10%"><?php _e('内容长度', 'wordpress-toolkit'); ?></th>
                                    <th scope="col" width="15%"><?php _e('发布日期', 'wordpress-toolkit'); ?></th>
                                    <th scope="col" width="20%"><?php _e('操作', 'wordpress-toolkit'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($excerpt_list['posts'] as $post): ?>
                                <tr>
                                    <td>
                                        <strong><a href="<?php echo esc_url($post['edit_url']); ?>" target="_blank"><?php echo esc_html($post['title']); ?></a></strong>
                                        <?php if ($post['status'] !== 'publish'): ?>
                                        <span class="status-draft">草稿</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($post['has_excerpt']): ?>
                                            <span class="status-active"><?php _e('有摘要', 'wordpress-toolkit'); ?></span>
                                            <?php if (isset($post['is_ai_generated']) && $post['is_ai_generated']): ?>
                                            <span class="ai-badge" style="margin-left: 5px; background: #e6f3ff; color: #0073aa; padding: 2px 6px; border-radius: 3px; font-size: 11px; border: 1px solid #b3d9ff; font-weight: 500;">🤖 AI</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="status-inactive"><?php _e('无摘要', 'wordpress-toolkit'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $post['excerpt_length']; ?> <?php _e('字符', 'wordpress-toolkit'); ?></td>
                                    <td><?php echo $post['content_length']; ?> <?php _e('字符', 'wordpress-toolkit'); ?></td>
                                    <td><?php echo $post['date']; ?></td>
                                    <td>
                                        <a href="<?php echo esc_url($post['edit_url']); ?>" class="button button-small" target="_blank"><?php _e('编辑', 'wordpress-toolkit'); ?></a>
                                        <a href="<?php echo esc_url($post['view_url']); ?>" class="button button-small" target="_blank"><?php _e('查看', 'wordpress-toolkit'); ?></a>
                                        <?php if (!$post['has_excerpt']): ?>
                                        <button type="button" class="button button-small button-primary generate-excerpt-single" data-post-id="<?php echo $post['ID']; ?>" title="为这篇生成智能摘要">
                                            生成摘要
                                        </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                            <?php } // End of else from posts check ?>
                    </div>
                </div>
            </div>

            <style>
            /* 简化的状态样式 */
            .status-active {
                color: #00a32a;
                font-weight: bold;
            }
            .status-inactive {
                color: #d63638;
                font-weight: bold;
            }
            .status-draft {
                display: inline-block;
                background: #f0f0f1;
                color: #50575e;
                padding: 2px 8px;
                border-radius: 3px;
                font-size: 11px;
                font-weight: 500;
                margin-left: 8px;
            }
            .badge-ai {
                display: inline-block;
                background: linear-gradient(135deg, #0073aa, #005a87);
                color: #fff;
                padding: 4px 12px;
                border-radius: 16px;
                font-size: 12px;
                font-weight: 500;
            }

            /* 使用WordPress标准分页样式，保持与后台其他功能一致 */

            /* 统一所有操作按钮宽度 */
            .tablenav td .button.button-small {
                min-width: 60px !important;
                max-width: 70px !important;
                white-space: nowrap !important;
                text-align: center !important;
                padding: 0 8px !important;
                font-size: 13px !important;
                height: 30px !important;
                line-height: 28px !important;
                overflow: hidden !important;
                text-overflow: ellipsis !important;
                display: inline-block !important;
                vertical-align: middle !important;
            }
            .generate-excerpt-single {
                min-width: 95px !important;
                max-width: 105px !important;
                white-space: nowrap !important;
                text-align: center !important;
                padding: 0 10px !important;
                font-size: 13px !important;
                height: 30px !important;
                line-height: 28px !important;
                overflow: hidden !important;
                text-overflow: ellipsis !important;
                display: inline-flex !important;
                vertical-align: middle !important;
                align-items: center !important;
                justify-content: center !important;
                gap: 4px !important;
                border-radius: 3px !important;
                box-shadow: 0 1px 2px rgba(0,0,0,0.1) !important;
                transition: all 0.2s ease !important;
            }
            .generate-excerpt-single.button-primary {
                background: #0073aa !important;
                border-color: #0073aa !important;
                color: #fff !important;
            }
            .generate-excerpt-single.button-primary:hover {
                background: #005a87 !important;
                border-color: #005a87 !important;
                transform: translateY(-1px) !important;
                box-shadow: 0 2px 4px rgba(0,0,0,0.15) !important;
            }
            .generate-excerpt-single.button-secondary {
                background: #f6f7f7 !important;
                border-color: #ddd !important;
                color: #50575e !important;
            }
            .generate-excerpt-single.button-secondary:hover {
                background: #e9e9e9 !important;
                border-color: #bbb !important;
                transform: translateY(-1px) !important;
                box-shadow: 0 2px 4px rgba(0,0,0,0.15) !important;
            }
            .generate-excerpt-single .dashicons {
                font-size: 14px !important;
                height: 14px !important;
                width: 14px !important;
                vertical-align: middle !important;
                margin: 0 !important;
                display: inline-block !important;
                flex-shrink: 0 !important;
            }

            /* 分页样式优化 - 与网站卡片保持一致 */
            .tablenav-pages {
                margin-top: 0;
                background: #f8f9f9;
                padding: 8px 12px;
                border-radius: 4px;
                border: 1px solid #e5e5e5;
                font-size: 13px;
            }

            .tablenav-pages .displaying-num {
                margin-right: 10px;
                color: #50575e;
            }

            .tablenav-pages .page-numbers {
                display: inline-block;
                padding: 4px 8px;
                margin: 0 2px;
                border: 1px solid #ccc;
                text-decoration: none;
                border-radius: 3px;
            }

            .tablenav-pages .page-numbers.current {
                background: #0073aa;
                color: white;
                border-color: #0073aa;
            }

            .tablenav-pages .page-numbers:hover {
                background: #f1f1f1;
            }

            .tablenav-pages .page-numbers.current:hover {
                background: #0073aa;
            }
            </style>

            <script>
            jQuery(document).ready(function($) {
                // 批量生成摘要
                $('#batch-generate-excerpts').on('click', function(e) {
                    e.preventDefault();

                    var $button = $(this);
                    var $spinner = $('#batch-generate-spinner');
                    var $status = $('#batch-generate-status');
                    var $result = $('#batch-generate-result');

                    // 显示加载状态
                    $button.prop('disabled', true);
                    $spinner.show();
                    $status.text('正在为无摘要的文章生成摘要，请稍候...');
                    $result.hide();

                    // 发送AJAX请求
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'batch_generate_excerpts',
                            nonce: '<?php echo wp_create_nonce('batch_generate_excerpts_nonce'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                var data = response.data;
                                var message = '<div class="notice notice-success is-dismissible"><p>' +
                                    '批量生成摘要完成！<br>' +
                                    '成功：' + data.success_count + ' 篇<br>' +
                                    '失败：' + data.error_count + ' 篇';

                                if (data.error_count > 0) {
                                    message += '<br>详细信息请查看日志';
                                }

                                message += '</p></div>';
                                $result.html(message).show();
                                $status.text('批量生成摘要完成！');

                                // 3秒后刷新页面以显示更新后的数据
                                setTimeout(function() {
                                    window.location.reload();
                                }, 3000);
                            } else {
                                $result.html('<div class="notice notice-error"><p>批量生成失败：' + response.data.message + '</p></div>').show();
                                $status.text('批量生成失败，请重试');
                            }
                        },
                        error: function() {
                            $result.html('<div class="notice notice-error"><p>网络错误，请重试</p></div>').show();
                            $status.text('网络错误，请重试');
                        },
                        complete: function() {
                            $button.prop('disabled', false);
                            $spinner.hide();
                        }
                    });
                });

                // 单个文章生成摘要
                $('.generate-excerpt-single').on('click', function(e) {
                    e.preventDefault();

                    var $button = $(this);
                    var postId = $button.data('post-id');
                    var originalText = $button.html();

                    // 显示加载状态
                    $button.prop('disabled', true).html('<span class="dashicons dashicons-spinner"></span><span>生成中...</span>');

                    // 发送AJAX请求
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'generate_single_excerpt',
                            post_id: postId,
                            nonce: '<?php echo wp_create_nonce('generate_single_excerpt_nonce'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                var data = response.data;
                                var message = '<div class="notice notice-success is-dismissible"><p>' +
                                    '摘要生成成功！<br>' +
                                    '文章：' + data.post_title + '<br>' +
                                    '摘要长度：' + data.excerpt_length + ' 字符' +
                                    '</p></div>';

                                // 显示成功消息
                                $('#batch-generate-result').html(message).show();

                                // 更新按钮状态
                                $button.removeClass('button-primary').addClass('button-secondary')
                                       .html('<span class="dashicons dashicons-yes"></span><span>已生成</span>')
                                       .prop('disabled', true);

                                // 更新表格中的状态显示
                                var $row = $button.closest('tr');
                                var statusHtml = '<span class="status-active">有摘要</span>';
                                if (data.ai_generated) {
                                    statusHtml += '<span class="ai-badge" style="margin-left: 5px; background: #e6f3ff; color: #0073aa; padding: 2px 6px; border-radius: 3px; font-size: 11px; border: 1px solid #b3d9ff; font-weight: 500;">🤖 AI</span>';
                                }
                                $row.find('td:nth-child(2)').html(statusHtml);
                                $row.find('td:nth-child(3)').text(data.excerpt_length + ' 字符');

                            } else {
                                // 显示错误消息
                                $('#batch-generate-result').html('<div class="notice notice-error"><p>摘要生成失败：' + response.data.message + '</p></div>').show();
                                $button.html(originalText).prop('disabled', false);
                            }
                        },
                        error: function() {
                            $('#batch-generate-result').html('<div class="notice notice-error"><p>网络错误，请重试</p></div>').show();
                            $button.html(originalText).prop('disabled', false);
                        }
                    });
                });
            });
            </script>
            <?php
        } else {
            echo '<div class="wrap"><div class="error"><p>' . __('自动摘要模块未正确加载', 'wordpress-toolkit') . '</p></div></div>';
        }
    }

    /**
     * 自动摘要设置页面 - 设置菜单中
     */
    public function auto_excerpt_settings_page() {
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            wp_die(__('权限不足', 'wordpress-toolkit'));
        }

        // 验证nonce（防止CSRF攻击）
        if (isset($_POST['action']) && !wp_verify_nonce($_POST['_wpnonce'], 'wordpress_toolkit_auto_excerpt')) {
            wp_die(__('安全验证失败', 'wordpress-toolkit'));
        }

        if ($this->auto_excerpt) {
            // 调用自动摘要模块的设置页面
            $this->auto_excerpt->settings_page();
        } else {
            echo '<div class="wrap"><h1>' . __('自动摘要设置', 'wordpress-toolkit') . '</h1><div class="error"><p>' . __('Auto Excerpt 模块未正确加载，请检查插件设置。', 'wordpress-toolkit') . '</p></div></div>';
        }
    }

/**
     * 网站卡片页面 - 放在工具箱菜单中
     */
    public function custom_cards_list_page() {
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            wp_die(__('权限不足', 'wordpress-toolkit'));
        }

        // 验证nonce（防止CSRF攻击）
        if (isset($_POST['action']) && !wp_verify_nonce($_POST['_wpnonce'], 'wordpress_toolkit_custom_card')) {
            wp_die(__('安全验证失败', 'wordpress-toolkit'));
        }

        // 调试日志
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('WordPress Toolkit: Custom Cards list page called');
        }

        if ($this->custom_card) {
            // 调用自定义卡片模块的卡片列表页面
            $this->custom_card->cards_list_page();
        } else {
            echo '<div class="wrap"><div class="error"><p>Custom Card 模块未正确加载，请检查插件设置。</p></div></div>';
        }
    }
    
    /**
     * Age Calculator管理页面 - 安全版本
     */
    public function age_calculator_admin_page() {
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            wp_die(__('权限不足', 'wordpress-toolkit'));
        }
        
        // 验证nonce（防止CSRF攻击）
        if (isset($_POST['action']) && !wp_verify_nonce($_POST['_wpnonce'], 'wordpress_toolkit_age_calculator')) {
            wp_die(__('安全验证失败', 'wordpress-toolkit'));
        }
        
        if ($this->age_calculator) {
            $this->age_calculator->admin_page();
        }
    }
    
    /**
     * Time Capsule管理页面 - 安全版本
     */
    public function time_capsule_admin_page() {
        // 验证用户权限 - 允许管理员和订阅者访问
        if (!current_user_can('manage_options') && !current_user_can('read')) {
            wp_die(__('权限不足', 'wordpress-toolkit'));
        }

        // 验证nonce（防止CSRF攻击）- 只在有POST数据时验证
        if (!empty($_POST) && isset($_POST['action']) && !wp_verify_nonce($_POST['_wpnonce'], 'wordpress_toolkit_time_capsule')) {
            wp_die(__('安全验证失败', 'wordpress-toolkit'));
        }

        if ($this->time_capsule) {
            $this->time_capsule->admin_page();
        }
    }

    /**
     * 友情链接管理页面 - 统一管理页面
     */
    public function friendlinks_admin_page() {
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            wp_die(__('权限不足', 'wordpress-toolkit'));
        }

        // 简化验证 - 将nonce验证移到具体的操作处理函数中
        // 避免在页面加载时进行验证，防止误报

        if ($this->simple_friendlink_admin) {
            // 调用友情链接管理页面的统一视图
            $this->simple_friendlink_admin->unified_admin_page();
        } else {
            echo '<div class="wrap"><div class="error"><p>' . __('友情链接管理模块未正确加载', 'wordpress-toolkit') . '</p>';
            echo '<br><strong>调试信息:</strong><br>';
            echo 'simple_friendlink_admin: ' . ($this->simple_friendlink_admin ? '已加载' : '未加载') . '<br>';
            echo 'simple_friendlink: ' . ($this->simple_friendlink ? '已加载' : '未加载') . '<br>';
            echo 'WordPress工具包版本: ' . WORDPRESS_TOOLKIT_VERSION . '<br>';
            echo '</p></div></div>';
        }
    }

    /**
     * CookieGuard管理页面 - 安全版本
     */
    public function cookieguard_admin_page() {
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            wp_die(__('权限不足', 'wordpress-toolkit'));
        }
        
        // 验证nonce（防止CSRF攻击）
        if (isset($_POST['action']) && !wp_verify_nonce($_POST['_wpnonce'], 'wordpress_toolkit_cookieguard')) {
            wp_die(__('安全验证失败', 'wordpress-toolkit'));
        }
        
        if ($this->cookieguard) {
            $this->cookieguard->admin_page();
        }
    }
    
    
    /**
     * 功能说明页面 - 统一的功能说明
     */
    public function toolbox_about_page() {
        // 验证用户权限
        if (!current_user_can('manage_options')) {
            wp_die(__('权限不足', 'wordpress-toolkit'));
        }
        ?>
        <div class="wrap">
            <h1>WordPress Toolkit - 功能说明</h1>
            <div class="wordpress-toolkit-about">

                <div class="about-section">
                    <h2>网站卡片模块</h2>
                    <div class="feature-card">
                        <h3>主要功能</h3>
                        <ul>
                            <li>自动抓取网站元数据（标题、描述、图片）</li>
                            <li>生成美观的网站卡片展示</li>
                            <li>支持懒加载和即时加载两种模式</li>
                            <li>多级缓存支持（数据库、Memcached、Opcache）</li>
                            <li>Gutenberg区块编辑器支持</li>
                        </ul>
                        
                        <h3>使用方法</h3>
                        <p>使用短代码 <code>[custom_card url="https://example.com"]</code> 或 <code>[custom_card_lazy url="https://example.com"]</code></p>
                        <p>在Gutenberg编辑器中搜索"Custom Card"区块</p>
                    </div>
                </div>
                
                <div class="about-section">
                    <h2>年龄计算器模块</h2>
                    <div class="feature-card">
                        <h3>主要功能</h3>
                        <ul>
                            <li>精确计算周岁年龄，考虑闰年2月29日</li>
                            <li>支持多种显示格式（年、月、天、详细）</li>
                            <li>自动计算和手动计算两种模式</li>
                            <li>支持自定义页面模板</li>
                            <li>用户生日记忆功能（登录用户）</li>
                        </ul>
                        
                        <h3>使用方法</h3>
                        <p>使用短代码 <code>[manus_age_calculator]</code> 显示计算器表单</p>
                        <p>使用短代码 <code>[manus_age_calculator_form]</code> 仅显示表单</p>
                        <p>使用页面模板"年龄计算器页面"创建专用页面</p>
                    </div>
                </div>
                
                <div class="about-section">
                    <h2>物品管理模块</h2>
                    <div class="feature-card">
                        <h3>主要功能</h3>
                        <ul>
                            <li>记录和管理个人物品购买信息</li>
                            <li>追踪物品使用情况和保修状态</li>
                            <li>分类管理物品（电子产品、家居用品、服装等）</li>
                            <li>保修到期提醒功能</li>
                            <li>数据统计和分析</li>
                        </ul>
                        
                        <h3>使用方法</h3>
                        <p>使用短代码 <code>[time_capsule]</code> 显示物品列表和添加表单</p>
                        <p>使用短代码 <code>[time_capsule_item id="123"]</code> 显示单个物品详情</p>
                        <p>使用页面模板"物品管理页面"创建专用页面</p>
                    </div>
                </div>
                
                <div class="about-section">
                    <h2>Cookie同意模块</h2>
                    <div class="feature-card">
                        <h3>主要功能</h3>
                        <ul>
                            <li>符合GDPR要求的Cookie同意通知</li>
                            <li>苹果风格设计，美观易用</li>
                            <li>多语言支持</li>
                            <li>自定义样式和文案</li>
                            <li>用户偏好记忆</li>
                        </ul>
                        
                        <h3>使用方法</h3>
                        <p>模块自动启用，无需短代码</p>
                        <p>在后台设置中配置Cookie通知样式和内容</p>
                        <p>支持自定义CSS样式覆盖</p>
                    </div>
                </div>

                <div class="about-section">
                    <h2>友情链接模块</h2>
                    <div class="feature-card">
                        <h3>主要功能</h3>
                        <ul>
                            <li>完整的友情链接管理系统</li>
                            <li>支持链接分类和状态管理</li>
                            <li>用户提交友情链接功能</li>
                            <li>管理员审核机制（统一管理界面）</li>
                            <li>响应式网格布局展示</li>
                            <li>支持网站Logo和描述</li>
                            <li>搜索和分页功能</li>
                            <li>专用页面模板</li>
                            <li>AJAX表单提交</li>
                        </ul>

                        <h3>后台管理</h3>
                        <p>管理员可在"工具箱" → "友情链接管理"中统一管理所有友情链接</p>
                        <p>管理页面包含"已发布链接"和"待审核申请"两个标签页</p>
                        <p>支持批量操作、单个审核、删除等功能</p>

                        <h3>前端显示</h3>
                        <p>使用页面模板"友情链接页面"或"简洁友情链接页面"创建专用页面</p>
                        <p>页面将自动包含完整的友情链接展示和提交功能</p>
                    </div>
                </div>

                <div class="about-section">
                    <h2>自动摘要模块</h2>
                    <div class="feature-card">
                        <h3>主要功能</h3>
                        <ul>
                            <li>🤖 <strong>DeepSeek AI智能摘要生成</strong> - 基于AI理解文章核心内容</li>
                            <li>🔄 <strong>智能降级机制</strong> - AI失败时自动使用本地算法</li>
                            <li>📝 <strong>中英文混合处理</strong> - 完美支持多语言内容</li>
                            <li>⚙️ <strong>灵活参数配置</strong> - 可调节创造性、长度等参数</li>
                            <li>🎯 <strong>精准摘要控制</strong> - 保持语义完整，突出重点</li>
                            <li>🕐 <strong>定时自动生成</strong> - 凌晨3点自动为无摘要文章生成摘要</li>
                            <li>📊 <strong>统计和筛选</strong> - 实时统计摘要覆盖率和AI生成情况</li>
                            <li>🔧 <strong>API连接测试</strong> - 确保AI服务正常工作</li>
                            <li>📝 <strong>程序化调用</strong> - 可供其他功能代码调用</li>
                            <li>🛡️ <strong>编辑页面兼容</strong> - 避免空白页面问题</li>
                        </ul>

                        <h3>AI生成优势</h3>
                        <p>使用DeepSeek AI技术，能够深度理解文章内容，生成更准确、更符合语义的摘要。相比传统算法，AI生成的摘要具有更好的连贯性和概括性。</p>

                        <h3>AI生成模式详解</h3>
                        <p><strong>技术特点：</strong></p>
                        <ul>
                            <li>需要配置DeepSeek API密钥（格式：sk-xxxxxx）</li>
                            <li>AI会根据文章内容生成更准确、更智能的摘要</li>
                            <li>支持中英文混合内容的智能理解</li>
                            <li>可以调节创造性参数控制摘要风格（0.0-1.0）</li>
                            <li>支持deepseek-chat和deepseek-reasoner两种模型</li>
                        </ul>

                        <p><strong>官方文档：</strong></p>
                        <p>详细API说明请参考： <a href="https://api-docs.deepseek.com/zh-cn/" target="_blank">DeepSeek API文档</a></p>

                        <p><strong>当前功能状态：</strong></p>
                        <ul>
                            <li>✅ AI配置和API测试功能完全正常</li>
                            <li>✅ DeepSeek API集成正常工作</li>
                            <li>✅ 摘要生成算法可供其他功能调用</li>
                            <li>✅ 定时任务功能正常工作</li>
                            <li>⚠️ 文章编辑页面功能已暂时禁用</li>
                        </ul>

                        <p><strong>技术说明：</strong></p>
                        <p>为了避免WordPress编辑页面出现空白问题，已暂时移除编辑页面的集成功能。核心的AI摘要生成功能完全保留，可以通过代码调用或在未来版本中通过其他方式使用。</p>

                        <p><strong>定时任务功能：</strong></p>
                        <ul>
                            <li>每天凌晨3点自动为没有摘要的文章生成摘要</li>
                            <li>连续3天没有生成摘要则自动停止任务</li>
                            <li>支持AI生成和传统算法的智能降级</li>
                            <li>具有完善的错误处理和日志记录</li>
                        </ul>

                        <h3>使用方法</h3>
                        <p><strong>功能管理：</strong>在"工具箱" → "自动摘要"中查看功能状态和概览</p>
                        <p><strong>AI配置：</strong>在"设置" → "自动摘要"中配置DeepSeek API密钥和相关参数</p>
                        <p><strong>API测试：</strong>在设置页面测试API连接是否正常工作</p>
                        <p><strong>批量生成：</strong>在功能管理页面可批量生成所有无摘要文章的摘要</p>
                        <p><strong>程序调用：</strong>摘要生成功能可供其他插件或主题代码调用</p>

                        <h3>后台管理</h3>
                        <p><strong>工具箱 → 自动摘要：</strong>查看功能概览、统计数据和批量操作</p>
                        <p><strong>设置 → 自动摘要：</strong>完整配置和参数调整</p>
                        <p>支持DeepSeek AI配置、连接测试、定时任务设置和参数调整</p>

                        <h3>注意事项</h3>
                        <p>• 需要配置DeepSeek API密钥才能使用AI生成功能</p>
                        <p>• API调用会产生费用，请参考DeepSeek的定价说明</p>
                        <p>• 启用降级机制可确保服务高可用性</p>
                        <p>• 首次使用建议先测试API连接是否正常</p>
                        <p>• deepseek-reasoner模型不支持自定义长度和创造性参数</p>
                        <p>• 建议在调试模式下启用WP_DEBUG以查看详细API日志</p>
                        <p>• API密钥请妥善保管，避免在代码中硬编码</p>
                    </div>
                </div>

                <div class="about-section">
                    <h2>通用功能</h2>
                    <div class="feature-card">
                        <h3>所有模块共享的功能</h3>
                        <ul>
                            <li>响应式设计，支持移动端</li>
                            <li>多语言支持（国际化）</li>
                            <li>权限控制，确保安全性</li>
                            <li>详细的错误处理和日志记录</li>
                            <li>定期更新和维护</li>
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
        
        <style>
        .wordpress-toolkit-about {
            max-width: 100%;
            box-sizing: border-box;
            width: 100%;
        }
        
        .about-section {
            margin-bottom: 30px;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            width: 100%;
            box-sizing: border-box;
        }
        
        .about-section h2 {
            color: #2271b1;
            border-bottom: 2px solid #2271b1;
            padding-bottom: 10px;
            margin-top: 0;
        }
        
        .feature-card {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 6px;
            border-left: 4px solid #2271b1;
            width: 100%;
            box-sizing: border-box;
        }
        
        .feature-card h3 {
            color: #2c3338;
            margin-top: 0;
        }
        
        .feature-card ul {
            margin: 10px 0;
            padding-left: 20px;
        }
        
        .feature-card li {
            margin-bottom: 5px;
            line-height: 1.5;
        }
        
        .feature-card code {
            background: #f0f0f1;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: monospace;
        }
        
        /* 响应式设计 */
        @media screen and (max-width: 782px) {
            .about-section {
                padding: 15px;
                margin-bottom: 20px;
            }
            
            .feature-card {
                padding: 15px;
            }
            
            .feature-card h3 {
                font-size: 16px;
            }
        }
        </style>
        <?php
    }
    
    /**
     * 添加插件操作链接
     */
    public function add_plugin_links($links) {
        $settings_link = '<a href="' . admin_url('admin.php?page=wordpress-toolkit') . '">设置</a>';
        $about_link = '<a href="' . admin_url('admin.php?page=wordpress-toolkit-about') . '">功能说明</a>';
        array_unshift($links, $about_link, $settings_link);
        return $links;
    }
}

// 初始化插件
WordPress_Toolkit::get_instance();
